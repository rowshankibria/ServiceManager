﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Itm.Data.Models
{
    public partial class Fw_v60_dev_storageContext : DbContext
    {
        public Fw_v60_dev_storageContext()
        {
        }

        public Fw_v60_dev_storageContext(DbContextOptions<Fw_v60_dev_storageContext> options)
            : base(options)
        {
        }

        public virtual DbSet<FileStore> FileStores { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("data source=itm-sql-01;initial catalog=Fw_v6.0_dev_storage;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<FileStore>(entity =>
            {
                entity.ToTable("FileStore");

                entity.HasIndex(e => e.Id)
                    .HasName("UK_FileStore_Id")
                    .IsUnique();

                entity.Property(e => e.Id).HasDefaultValueSql("(newsequentialid())");

                entity.Property(e => e.FileContent).IsRequired();

                entity.Property(e => e.TimeStamp).IsRowVersion();
            });
        }
    }
}
