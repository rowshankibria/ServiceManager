﻿using System;
using System.Collections.Generic;

namespace Itm.Data.Models
{
    public partial class Schema
    {
        public int Version { get; set; }
    }
}
