﻿using System;
using System.Collections.Generic;

namespace Itm.Data.Models
{
    public partial class Job
    {
        public Job()
        {
            JobParameters = new HashSet<JobParameter>();
            State1 = new HashSet<State1>();
        }

        public int Id { get; set; }
        public int? StateId { get; set; }
        public string StateName { get; set; }
        public string InvocationData { get; set; }
        public string Arguments { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? ExpireAt { get; set; }

        public ICollection<JobParameter> JobParameters { get; set; }
        public ICollection<State1> State1 { get; set; }
    }
}
