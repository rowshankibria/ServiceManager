﻿using System;
using System.Collections.Generic;

namespace Itm.Data.Models
{
    public partial class AspNetRole
    {
        public AspNetRole()
        {
            ApplicationRoleRights = new HashSet<ApplicationRoleRight>();
            AspNetRoleClaims = new HashSet<AspNetRoleClaim>();
            AspNetUserRoles = new HashSet<AspNetUserRole>();
            InverseParentRole = new HashSet<AspNetRole>();
        }

        public string Id { get; set; }
        public string Name { get; set; }
        public string NormalizedName { get; set; }
        public string ConcurrencyStamp { get; set; }
        public string Description { get; set; }
        public string ParentRoleId { get; set; }
        public int? BusinessProfileId { get; set; }
        public bool IsActive { get; set; }
        public byte[] TimeStamp { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int CreatedByContactId { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int? LastUpdatedByContactId { get; set; }

        public BusinessProfile BusinessProfile { get; set; }
        public Contact CreatedByContact { get; set; }
        public Contact LastUpdatedByContact { get; set; }
        public AspNetRole ParentRole { get; set; }
        public ICollection<ApplicationRoleRight> ApplicationRoleRights { get; set; }
        public ICollection<AspNetRoleClaim> AspNetRoleClaims { get; set; }
        public ICollection<AspNetUserRole> AspNetUserRoles { get; set; }
        public ICollection<AspNetRole> InverseParentRole { get; set; }
    }
}
