﻿using System;
using System.Collections.Generic;

namespace Itm.Data.Models
{
    public partial class FileStore
    {
        public Guid Id { get; set; }
        public byte[] FileContent { get; set; }
        public byte[] TimeStamp { get; set; }
    }
}
