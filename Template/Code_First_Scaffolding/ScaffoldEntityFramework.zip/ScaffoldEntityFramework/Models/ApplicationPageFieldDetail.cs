﻿using System;
using System.Collections.Generic;

namespace Itm.Data.Models
{
    public partial class ApplicationPageFieldDetail
    {
        public int Id { get; set; }
        public int PageId { get; set; }
        public string Name { get; set; }
        public string Caption { get; set; }
        public string CellTemplate { get; set; }
        public string DataType { get; set; }
        public bool? Visible { get; set; }
        public bool? ReadOnly { get; set; }
        public bool Required { get; set; }
        public bool IsUnique { get; set; }
        public bool? ColumnFilterEnabled { get; set; }
        public bool? RowFilterEnabled { get; set; }
        public bool? SortEnabled { get; set; }
        public bool IsDefaultSort { get; set; }
        public string Alignment { get; set; }
        public int RowNo { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int CreatedByContactId { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int? LastUpdatedByContactId { get; set; }

        public Contact CreatedByContact { get; set; }
        public Contact LastUpdatedByContact { get; set; }
        public ApplicationPage Page { get; set; }
    }
}
